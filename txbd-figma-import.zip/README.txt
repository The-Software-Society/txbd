TxBD Commemorative — Figma import bundle

Import this zip in html.to.design (File tab -> upload .zip).
It imports every webpage:
  00 Brand guidelines (tokens & components)
  01 Home / 02 Product / 03 Content (desktop)
  04 Component states (hover/open/active)
  05-07 Home/Product/Content (mobile)

Set the import viewport to Desktop (1440). The 05-07 mobile pages are
hard-framed to 390px so they import as phone layouts in the same pass.
